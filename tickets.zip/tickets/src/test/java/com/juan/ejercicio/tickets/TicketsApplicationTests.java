package com.juan.ejercicio.tickets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketsApplicationTests {

	@Test
	void contextLoads() {
	}

}
